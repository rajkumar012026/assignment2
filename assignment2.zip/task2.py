y = 0
for i in range(1, 51, 1):
    y = y + i
print(f'The sum of numbers from 1 to {i} is: {y}')