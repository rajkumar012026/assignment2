num = int(input("Enter a number: "))
y = num % 2
if y == 0:
    print(num, "is an even number")
elif y == 1:
    print(num, "is an odd number")

